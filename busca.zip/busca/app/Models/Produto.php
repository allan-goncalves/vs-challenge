<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produto extends  Model
{
    protected $table = 'produtos';

    protected $fillable=[
        'nome',
        'descricao',
        'marca',
    ];

    function getFillable() {
        return $this->fillable;
    }

    function setFillable($fillable) {
        $this->fillable = $fillable;
    }

   

}