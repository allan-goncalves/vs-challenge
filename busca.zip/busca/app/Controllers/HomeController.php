<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 28/03/2017
 * Time: 16:31
 */
namespace App\Controllers;
use App\Models\Produto;

use Slim\Views\Twig as View;

class HomeController extends Controller
{
    public function index($request,$response)
    {
        $m = Produto::groupBy('marca')
               ->get();
         foreach ($m as $key => $value) {
            $marcas['marcas'][$key]['marca'] = $value['attributes']['marca'];
            $marcas['marcas'][$key]['id'] = $value['attributes']['id'];
        }
        return $this->view->render($response,'home.twig',$marcas);
    }
    
    
}
