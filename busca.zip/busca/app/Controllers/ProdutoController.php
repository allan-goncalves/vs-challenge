<?php

namespace App\Controllers;

use App\Models\Produto;
use Slim\Views\Twig as View;

class ProdutoController extends Controller {

    public function insertProduto($request, $response) {
        $produto = Produto::create([
                    'nome' => $request->getParam('nome'),
                    'descricao' => $request->getParam('descricao'),
                    'marca' => $request->getParam('marca')
        ]);

        $this->flash->addMessage('info', 'Salvo com sucesso!');
        return $response->withRedirect($this->router->pathFor('produto.cadastrar'));
    }

    public function updateProduto($request, $response) {
        $p = new Produto();
        $produto = $p->find($request->getParam('idproduto'));
        $produto->nome = $request->getParam('nome');
        $produto->descricao = $request->getParam('descricao');
        $produto->marca = $request->getParam('marca');
        $produto->save();
        $this->flash->addMessage('info', 'Salvo com sucesso!');
        return $response->withRedirect($this->router->pathFor('produto.cadastrar'));
    }

    public function buscarTodosProdutos() {
        return Produto::all();
    }

    public function pesquisarProduto($request, $response) {
        $marca = $request->getParam('marca');
        $prod = $request->getParam('produto');
        if ($prod) {
            $res = Produto::where([
                        'id' => $prod,
                        'marca' => $marca
                 ])->get();
        } else {
            $res = Produto::where('marca', $marca)
                    ->get();
        }

        foreach ($res as $key => $value) {
            $produtos['produtos'][$key]['nome'] = $value['attributes']['nome'];
            $produtos['produtos'][$key]['descricao'] = $value['attributes']['descricao'];
            $produtos['produtos'][$key]['marca'] = $value['attributes']['marca'];
            $produtos['produtos'][$key]['id'] = $value['attributes']['id'];
        }
        $produtos["prod"] = $this->buscarProdutos($marca);
        $produtos["marcas"] = $this->buscarMarcas();
        return $this->view->render($response, 'home.twig', $produtos);
    }

    public function editarProduto($request, $response) {
        $id = $request->getParam('idproduto');
        $p = Produto::where('id', $id)->first();
        $produto['nome'] = $p->nome;
        $produto['descricao'] = $p->descricao;
        $produto['marca'] = $p->marca;
        $produto['id'] = $p->id;
        return $this->view->render($response, 'produto/produto.twig', $produto);
    }

    public function deleteProduto($request, $response) {
        $p = new Produto();
        $produto = $p->find($request->getParam('idproduto'));
        $produto->delete();
        $this->flash->addMessage('info', 'Deletado com sucesso!');
        return $response->withRedirect($this->router->pathFor('produto.cadastrar'));
    }

    public function buscarProdutos($marca) {
         $prod = Produto::where('marca', $marca)
                    ->get();
        foreach ($prod as $key => $value) {
            $p[$key]['nome'] = $value['attributes']['nome'];
            $p[$key]['id'] = $value['attributes']['id'];
        }
        return $p;
    }
    public function buscarMarcas() {
        $m = Produto::groupBy('marca')
                ->get();
        foreach ($m as $key => $value) {
            $marcas[$key]['marca'] = $value['attributes']['marca'];
            $marcas[$key]['id'] = $value['attributes']['id'];
        }
        return $marcas;
    }
   

    public function cadastrarProduto($request, $response) {
        $prod = $this->buscarTodosProdutos();
        foreach ($prod as $key => $value) {
            $produtos['produtos'][$key]['nome'] = $value['attributes']['nome'];
            $produtos['produtos'][$key]['descricao'] = $value['attributes']['descricao'];
            $produtos['produtos'][$key]['marca'] = $value['attributes']['marca'];
            $produtos['produtos'][$key]['id'] = $value['attributes']['id'];
        }
        return $this->view->render($response, 'produto/produto.twig', $produtos);
    }

}
