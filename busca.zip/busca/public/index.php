<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 28/03/2017
 * Time: 15:04
 */
require __DIR__ .'/../bootstrap/app.php';

$app->run();